# Topsis-Package

## A simple package to implement TOPSIS.
